Setting up && running !

Go to [ WCU ] base directory and fire up [ http-server ], provided that you have Node.js installed on your computer !
Navigate to examplary_usage_module/View/ to kick-off the page load !


Paths definition:
 - all paths are relative to View/Index.html, i.e. to View/




==================================
 How it really works ?
==================================
  Go to OneDrive directory under this address [ https://1drv.ms/f/s!Av2ZrNqOVnWL9yW0tKXfC3v-oCxz ] for all on Website Control Unit !